package com.bannerview.config

enum class Animate {
    DepthPageTransformer,
    ZoomOutPageTransformer
}