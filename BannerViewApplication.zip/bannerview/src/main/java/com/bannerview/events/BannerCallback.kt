package com.bannerview.events

interface BannerCallback {
    fun onSelectBanner(pos: Int)
}