package com.bannerview.events

interface ItemClickListeners {
    fun onItemClicked(post: Int)
}